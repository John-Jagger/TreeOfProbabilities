
/**
 * All the text for the forest.
 *
 * @author John Jagger
 * @version 1.0.0
 */
public class actionsAndResults
{
    public static void time1()
    {
        System.out.println("What planet do you want to focus?");
        System.out.println("- earth");
        System.out.println("- venus");
    }
    public static void time2()
    {
        System.out.println("Is earth filled with light or darkness");
        System.out.println("- light");
        System.out.println("- darkness");
    }
    public static void time3()
    {
        System.out.println("Did the galaxy collapse or is it propsering");
        System.out.println("- collapse");
        System.out.println("- prosper");
    }
    public static void time4()
    {
        System.out.println("Are the champions of earth worthy or unworthy?");
        System.out.println("- worthy");
        System.out.println("- unworthy");
    }
    public static void time5()
    {
        System.out.println("The souls of the many, are they weak or strong?");
        System.out.println("- weak");
        System.out.println("- strong");
    }
    public static void time6()
    {
        System.out.println("The life forms of the plant did they look into the void or resisted it?");
        System.out.println("- looked");
        System.out.println("- resisted");
    }
    public static void time7()
    {
        System.out.println("Was life in the world golden or rebuilding");
        System.out.println("- gold");
        System.out.println("- rebuilding");
    }
    public static void time8()
    {
        System.out.println("Did the darkend one awaken");
        System.out.println("- unveiled");
        System.out.println("- unrevealed");
    }
    public static void time9()
    {
        System.out.println("Was the moon sleeping soundly?");
        System.out.println("- yes");
        System.out.println("- no");
    }
    public static void time10()
    {
        System.out.println("Human populations lose?");
        System.out.println("- 50");
        System.out.println("- 90");
    }
    public static void time11()
    {
        System.out.println("Did the champion stand?");
        System.out.println("- yes");
        System.out.println("- no");
    }
    public static void time12()
    {
        System.out.println("What filled the system?");
        System.out.println("- hope");
        System.out.println("- fear");
    }
    public static void time13()
    {
        System.out.println("Did the tyrant still stand?");
        System.out.println("- fall");
        System.out.println("- stood");
    }
    public static void time14()
    {
        System.out.println("Did the tyrant stand?");
        System.out.println("- fall");
        System.out.println("- stood");
    }
    public static void time15()
    {
        System.out.println("Would the mind of the many join or cry?");
        System.out.println("- joined");
        System.out.println("- cried");
    }
    public static void time16()
    {
        System.out.println("What filled the souls of many?");
        System.out.println("- hope");
        System.out.println("- weakness");
    }
    public static void time17()
    {
        System.out.println("What filled the soils of venus?");
        System.out.println("- light");
        System.out.println("- darkness");
    }
    public static void time18()
    {
        System.out.println("Was the vault of venus stood or be broken");
        System.out.println("- stood");
        System.out.println("- broken"); 
    }
    public static void time19()
    {
        System.out.println("Was the heart of the garden beating on?");
        System.out.println("- no");
        System.out.println("- yes");
    }
    public static void time20()
    {
        System.out.println("Are the worriors of humans ready?");
        System.out.println("- knowledgeable");
        System.out.println("- dumb");
    }
    public static void time21()
    {
        System.out.println("Did the vault ritual finish");
        System.out.println("- prevented");
        System.out.println("- stood");
    }
    public static void time22()
    {
        System.out.println("The king of the taken, where was he?");
        System.out.println("- planning");
        System.out.println("- rested");
    }
    public static void time23()
    {
        System.out.println("Was a trap set?");
        System.out.println("- yes");
        System.out.println("- no");
    }
    public static void time24()
    {
        System.out.println("Was the last mind of the heart planning?");
        System.out.println("- yes");
        System.out.println("- no");
    }
    public static void time25()
    {
        System.out.println("Did the veil power the vault?");
        System.out.println("- powered");
        System.out.println("- no");
    }
    public static void time26()
    {
        System.out.println("Was the vault re-opened?");
        System.out.println("- closed");
        System.out.println("- opened");
    }
    public static void time27()
    {
        System.out.println("Was a sin reborn?");
        System.out.println("- yes");
        System.out.println("- no");
    }
    public static void time28()
    {
        System.out.println("Was the time engine working?");
        System.out.println("- powered");
        System.out.println("- left");
    }
    public static void time29()
    {
        System.out.println("Was the finality working?");
        System.out.println("- broken");
        System.out.println("- shaped");
    }
    public static void time30()
    {
        System.out.println("Was the life of metal powered?");
        System.out.println("- powered");
        System.out.println("- broken");
    }
    public static void time31()
    {
        System.out.println("Was there hope?");
        System.out.println("- hope");
        System.out.println("- hopeless");
    }
    public static void time32()
    {
        System.out.println("You have choosen past, which planet is the center of you effects?");
        System.out.println("- earth");
        System.out.println("- mercury");
    }
    public static void time33()
    {
        System.out.println("Does the light fill the system or is it blinded");
        System.out.println("- light");
        System.out.println("- blinded");
    }
    public static void time34()
    {
        System.out.println("What do the souls sing?");
        System.out.println("- sorrow");
        System.out.println("- happiness");
    }
    public static void time35()
    {
        System.out.println("Does the heart or sword threaten the earth?");
        System.out.println("- heart");
        System.out.println("- sword");
    }
    public static void time36()
    {
        System.out.println("Is what fills the space between forms?");
        System.out.println("- hope");
        System.out.println("- hopeless");
    }
    public static void time37()
    {
        System.out.println("How are the minds of the many?");
        System.out.println("- bright");
        System.out.println("- punch");
    }
    public static void time38()
    {
        System.out.println("Is there a change in the system? ");
        System.out.println("- yes");
        System.out.println("- no");
    }
    public static void time39()
    {
        System.out.println("Where was this?");
        System.out.println("- titan");
        System.out.println("- moon");
    }
    public static void time40()
    {
        System.out.println("Has a tyrant been formed or is has the system awaken?");
        System.out.println("- formed");
        System.out.println("- awaken");
    }
    public static void time41()
    {
        System.out.println("Does earth visit mars?");
        System.out.println("- visit");
        System.out.println("- ignore");
    }
    public static void time42()
    {
        System.out.println("What was on mars?");
        System.out.println("- hope");
        System.out.println("- dread");
    }
    public static void time43()
    {
        System.out.println("What was there reaction?");
        System.out.println("- welcome");
        System.out.println("- fear");
    }
    public static void time44()
    {
        System.out.println("The coming end, did it scare them or anger them?");
        System.out.println("- scare");
        System.out.println("- anger");
    }
    public static void time45()
    {
        System.out.println("Does the veil wrecthed eye seek earth?");
        System.out.println("- passes");
        System.out.println("- ignore");
    }
    public static void time46()
    {
        System.out.println("Does the eye seek more or ignore");
        System.out.println("- stays");
        System.out.println("- leaves");
    }
    public static void time47()
    {
        System.out.println("Does the light fill the system or is it blinded");
        System.out.println("- light");
        System.out.println("- blinded");
    }
    public static void time48()
    {
        System.out.println("What fills the soil of mercury?");
        System.out.println("- hope");
        System.out.println("- dread");
    }
    public static void time49()
    {
        System.out.println("Is the endless forest open or closed?");
        System.out.println("- opened");
        System.out.println("- closed");
    }
    public static void time50()
    {
        System.out.println("Has a seed of time been planted before?");
        System.out.println("- planted");
        System.out.println("- no");
    }
    public static void time51()
    {
        System.out.println("Do you free the most dangerous prisoner of the time learners?");
        System.out.println("- free");
        System.out.println("- dont");
    }
    public static void time52()
    {
        System.out.println("What does the forest smell of?");
        System.out.println("- either");
        System.out.println("- gas");
    }
    public static void time53()
    {
        System.out.println("What are learners of time planning? A becon from the garden or to plant to seeds of time?");
        System.out.println("- becon");
        System.out.println("- growing");
    }
    public static void time54()
    {
        System.out.println("Does there becon reach the edge of the void?");
        System.out.println("- yes");
        System.out.println("- no");
    }
    public static void time55()
    {
        System.out.println("Does there seed grow into a forest?");
        System.out.println("- yes");
        System.out.println("- no");
    }
    public static void time56()
    {
        System.out.println("The golden eye of the few, is he present or scearhing?");
        System.out.println("- present");
        System.out.println("- sreaching");
    }
    public static void time57()
    {
        System.out.println("Is the corriodors spinning or are the houses active?");
        System.out.println("- spinning");
        System.out.println("- active");
    }
    public static void time58()
    {
        System.out.println("Does the champion follow a path of power or furtune?");
        System.out.println("- power");
        System.out.println("- fortune");
    }
    public static void time59()
    {
        System.out.println("What do the towers hum?");
        System.out.println("- single note");
        System.out.println("- double note");
    }
    public static void time60()
    {
        System.out.println("Do the time learners gather or are they scattered");
        System.out.println("- gather");
        System.out.println("- scatter");
    }
    public static void time61()
    {
        System.out.println("When the vault stood did the heros run or conquier");
        System.out.println("- run");
        System.out.println("- conquier");
    }
    public static void time62()
    {
        System.out.println("Was the sol preparing?");
        System.out.println("- yes");
        System.out.println("- no");
    }
}
