
/**
 * The possible endings to each time line
 *
 * @author John Jagger
 * @version 1.0.0
 */
public class oneOfMany
{
    public static void ending1()
    {
        System.out.println("Title : Broken Legends");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Everything was prepared for the tower victory over the veil");
        System.out.println("but the veil used a secret weapon and almost destroyed the last city.");
        System.out.println("After a long adventure the darkness was pushed away!!");
    }
    public static void ending2()
    {
        System.out.println("Title : Unbroken Legends");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Everything was prepared for the tower victory over the veil");
        System.out.println("and before they could use a powerful weapon the guardians.");
        System.out.println("deafted the veil flag ship and gave hope to the traveler!");
    }
    public static void ending3()
    {
        System.out.println("Title : Weak Lengends");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Everything wasn't prepared for the tower victory over the veil.");
        System.out.println("When the veil asked the guardian to join them,");
        System.out.println("they accepted. . .");
    }
    public static void ending4()
    {
        System.out.println("Title : True Legends");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Everything wasn't prepared for the tower victory over the veil");
        System.out.println("When the veil asked the guardian to join them,");
        System.out.println("they denied the offer and fought to the end.");
    }
    public static void ending5()
    {
        System.out.println("Title : An Ending Age");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The golden age came to an end,");
        System.out.println("with the arrivel of the veil. . .");
    }
    public static void ending6()
    {
        System.out.println("Title : A Golden Age");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The golden age lived on and the moon");
        System.out.println("team has found new artifact.");
    }
    public static void ending7()
    {
        System.out.println("Title : A Waking Demon");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("In the age of guardians, the tower assaulted the moon");
        System.out.println("but the god like champion awaken and slaughtered the ");
        System.out.println("guardians of the tower. . .");
    }
    public static void ending8()
    {
        System.out.println("Title : A Rising Time");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("In the age of guardians, the Guarians have started to work");
        System.out.println("together, and the age of warlords are over.");
    }
    public static void ending9()
    {
        System.out.println("Title : The Candle in the Dark");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil killed 50% of the human population,");
        System.out.println("With the true champion of the light and his will,");
        System.out.println("he destroyed the veil and there leader.");
    }
    public static void ending10()
    {
        System.out.println("Title : A Slient Wimper");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil killed 50% of the human population,");
        System.out.println("But the true champion of the light lost his will,");
        System.out.println("the veil took over the traveler.");
    }
    public static void ending11()
    {
        System.out.println("Title : Failure of a god");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil killed 50% of the human population and the,");
        System.out.println("true champion of the light. The traveler");
        System.out.println("was destroyed by the veil.");
    }
    public static void ending12()
    {
        System.out.println("Title : In Times of Need");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil killed 50% of the human population and the,");
        System.out.println("true champion of the light. But the traveler gave it his all,");
        System.out.println("and took out the veil at the cost of his life.");
    }
    public static void ending13()
    {
        System.out.println("Title : If You can't Beat them, Join them");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil killed 90% of the human population,");
        System.out.println("with everything gone all the humans joined the veil.");
    }
    public static void ending14()
    {
        System.out.println("Title : A Weak Species");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil killed 90% of the human population,");
        System.out.println("and the rest of humanity weaped in there final moments.");
        System.out.println("The darkness had won, once again");
    }
    public static void ending15()
    {
        System.out.println("Title : Even Boys can Kill Giants");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil killed 90% of the human population,");
        System.out.println("But the reset of humanity can together, made a pack with");
        System.out.println("the fallen, they fought hard and long. Finally puching back the veil and saing earth.");
    }
    public static void ending16()
    {
        System.out.println("Title : Salvation's Cry");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil killed 90% of the human population.");
        System.out.println("The rest of humanity turned to hive practices and joined the pack.");
        System.out.println("They were saved, but at a cost of everything.");
    }
    public static void ending17()
    {
        System.out.println("Title : Smarter than Time Travelers");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The sol vex used the power of the black heart to take over the vault of glass.");
        System.out.println("The current gaurdians ruushed to the vault to push them back.");
        System.out.println("Thanks to the briliant minds they killed the gate lord and saved the city.");
    }
    public static void ending18()
    {
        System.out.println("Title : Brain > Bronze");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The sol vex used the power of the black heart to take over the vault of glass.");
        System.out.println("The current gaurdians rushed to the vault to push them back.");
        System.out.println("The gaurdians weren't the brightest and fell to the vex, the sol finished there project.");
        System.out.println("They made a mind at used the power of time and the heart. In days the last city was deleted.");
    }
    public static void ending19()
    {
        System.out.println("Title : Victors of the Vault");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The vex of venus used the power of the vault of glass to erase the traveler from this timeline.");
        System.out.println("The current gaurdians rushed to the vault to push them back.");
        System.out.println("The gaurdians deafted the Hydra and saved the timeline from unkown change.");
    }
    public static void ending20()
    {
        System.out.println("Title : 'Prefection'");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The vex of venus used the power of the vault of glass to erase the traveler from this timeline.");
        System.out.println("The current gaurdians rushed to the vault to push them back.");
        System.out.println("The gaurdians weren't the brightest and fell to the vex, the vex finished there attack.");
        System.out.println("It created a reality know to many as 'prefection'.");
    }
    public static void ending21()
    {
        System.out.println("Title : A King's Mess");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The assulted the vault of glass and took most of its vex.");
        System.out.println("The current gaurdians rushed to the vault to push his new army back.");
        System.out.println("The gaurdians cleared the vault and gained access to 'No Time to Explain'.");
    }
    public static void ending22()
    {
        System.out.println("Title : A Grand Battle to Happen");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The Taken King fled to his throne world.");
        System.out.println("He had plans for the vault, but must attend the guardian.");
        System.out.println("This results on guardians going to kill the taken king");
    }
    public static void ending23()
    {
        System.out.println("Title : A New Home");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The undying mind plans to us the vault of glass to recreate the balck heart.");
        System.out.println("The current gaurdians rushed to the vault to push him back.");
        System.out.println("The gaurdians kill him but can't stop the ritual. The heart is remade");
        System.out.println("and the vault is now the heart of the sol.");
    }
    public static void ending24()
    {
        System.out.println("Title : A Time of Peace");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The planet of venus is quiet.");
    }
    public static void ending25()
    {
        System.out.println("Title : A Probelm Reborn");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil use the vault of glass to create there old leader.");
        System.out.println("Ozot is reborn and attacks the last city");
        System.out.println("Thousands die, and the traveler is weakend");
    }
    public static void ending26()
    {
        System.out.println("Title : The Weekly Bad Guy");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil use the vault of glass to create there old leader.");
        System.out.println("The current gaurdians rushed to the vault to stop this.");
        System.out.println("The gaurdians deafet the veil and force them to retreat.");
    }
     public static void ending27()
    {
        System.out.println("Title : Traveler? What's that?");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil use the vault of glass to delete the traveler from ever exsiting.");
        System.out.println("This new purpose is being powered, and my delete the idea and concpet of a traveler");
    }
     public static void ending28()
    {
        System.out.println("Title : One Error to End them All.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil use the vault of glass to delete the traveler from ever exsiting.");
        System.out.println("The vault doesnt compute with the veils and the vault deletes all of the vex.");
        System.out.println("The systems implodes due to the changes that occured in seconds");
    }
     public static void ending29()
    {
        System.out.println("Title : The Day the Vex Attacked the City.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil flag ship, finality, was destroyed..");
        System.out.println("The veil try to make a vex mind they comtrol that could assult the city.");
        System.out.println("They create a mind of the veil and unleash it upon the last city");
    }
     public static void ending30()
    {
        System.out.println("Title : Another Strike Down.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil flag ship, finality, was destroyed..");
        System.out.println("The veil try to make a vex mind they comtrol that could assult the city.");
        System.out.println("They failed due to a guardians interventions");
    }
     public static void ending31()
    {
        System.out.println("Title : A Destroyed Ships Keeps the Veil Away.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil flag ship, finality, was here");
        System.out.println("It Targeted the Last City, from venus and was to destroy humanity.");
        System.out.println("They failed due to a guardians hope and light, destroying most of the veil.");
    }
     public static void ending32()
    {
        System.out.println("Title : It's all Gone.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The veil flag ship, finality, was here");
        System.out.println("It Targeted the Last City, from venus and was to destroy humanity.");
        System.out.println("The ship fires and earth is decimated.");
    }
    public static void ending33()
    {
        System.out.println("Title : A Guardians Tale.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the dark ages, the traveler was sick due to the weight of the heart.");
        System.out.println("This lead to sorrow and pain, until hope arrived and a guardian was risen.");
        System.out.println("He slaughtered the heart and started the next chapter of humanity.");
    }
    public static void ending34()
    {
        System.out.println("Title : Before the Light.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the dark ages, the traveler was sick due to the weight of the heart.");
        System.out.println("This lead to sorrow and pain, many guardians tried to stop it's power..");
        System.out.println("But they we're all slaughtered by the heart.");
    }
    public static void ending35()
    {
        System.out.println("Title : Spawn Killer.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the recovery ages, the traveler was going strength,but a weight of the hive grow upon him.");
        System.out.println("Crota, Oryx spawn was preparing to awake and attack earth.");
        System.out.println("A group of guardians went into the deep and ended his life alloing for the traveler to grow.");
    }
    public static void ending36()
    {
        System.out.println("Title : A Great Failure.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the recovery ages, the traveler was going strength,but a weight of the hive grow upon him.");
        System.out.println("Crota, Oryx spawn was preparing to awake and attack earth.");
        System.out.println("Guardians attacked the moon, only to be slaughtered. Thousands were lost that day.");
    }
    public static void ending37()
    {
        System.out.println("Title : A Golden Age Nightmare.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the golden age, a team find something on the moon.");
        System.out.println("It is something that sends messages to somewhere unkown.");
        System.out.println("It does one thing, makes poeple see what the fear most, something dark.");
    }
    public static void ending38()
    {
        System.out.println("Title : The End.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the golden age, titan is attacked with a gravity weapon, streching it out and letting go.");
        System.out.println("Cuasing a large 70 mile high wave, all caused by ships of darkness.");
        System.out.println("The collapse has started.");
    }
    public static void ending39()
    {
        System.out.println("Title : A Tyrant.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the golden age, humans started to fear what was next.");
        System.out.println("Though there was no treat to fear, they feared something.");
        System.out.println("So, clovis bray created Rasputin.");
    }
    public static void ending40()
    {
        System.out.println("Title : A Traveler.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the modern age, people explore mars.");
        System.out.println("They find the traveler and the golden age starts.");
    }
    public static void ending41()
    {
        System.out.println("Title : A Trip of a Life Time.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the modern age, people explore mars.");
        System.out.println("They find the traveler and welcome it to humanity and began the golden age.");
    }
    public static void ending42()
    {
        System.out.println("Title : A Missed Opertunity.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the modern age, people explore mars.");
        System.out.println("They find the traveler and fear it, so they leave it behind preventing the golden age.");
    }
    public static void ending43()
    {
        System.out.println("Title : A Trip of Death.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the modern age, people explore mars.");
        System.out.println("They find the Veil and fear it, in seconds moon crashes onto them.");
        System.out.println("Earth didn't last after this.");
    }
    public static void ending44()
    {
        System.out.println("Title : A Trip of a Rage.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the modern age, people explore mars.");
        System.out.println("They find the Veil and fear it, they feel their anger.");
        System.out.println("The veil welcome earth as one of its servents.");
    }
    public static void ending45()
    {
        System.out.println("Title : The Wrong Type of Attention.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the modern age, people didn't explore mars making the traveler leave the system.");
        System.out.println("The Veil enter it to follow the traveler.");
        System.out.println("They stay so they can make humanity join there cause, and they do.");
    }
    public static void ending46()
    {
        System.out.println("Title : Lucky.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the modern age, people didn't explore mars making the traveler leave the system.");
        System.out.println("The Veil enter it to follow the traveler.");
        System.out.println("They leave finding no interest humanity lives on.");
    }
    public static void ending47()
    {
        System.out.println("Title : Second Chance.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the modern age, people didn't explore mars making the traveler leave the system.");
        System.out.println("The Traveler comes back seeing how strog we could become.");
        System.out.println("We find it on earth and the golden age starts.");
    }
    public static void ending48()
    {
        System.out.println("Title : Normality.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("During the modern age, people didn't explore mars making the traveler leave the system.");
        System.out.println("Humanity lives on.");
    }
    public static void ending49()
    {
        System.out.println("Title : Savior.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The forest holds prisoner, throught the cubes of time you open the forest.");
        System.out.println("Yor freed the strongest titan, saint-14, and humanity has a new champion.");
    }
    public static void ending50()
    {
        System.out.println("Title : A Normal Day.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The forest holds prisoner, and you don't free him");
        System.out.println("A guardian, saint-14, dies becuase of this action. . .");
    }
    public static void ending51()
    {
        System.out.println("Title : A Fallen Raiding Party.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The forest smells of either. . .");
        System.out.println("Then the house of dusk attacks the forest trying to gain its secerts.");
        System.out.println("A captain was successful and uses the power against the city.");
    }
    public static void ending52()
    {
        System.out.println("Title : A War with the Cabal.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The forest smells of either. . .");
        System.out.println("Then the red leigon attacks the forest trying to gain its secerts.");
        System.out.println("A psion was successful and uses the power against the city.");
    }
    public static void ending53()
    {
        System.out.println("Title : A Day with Death.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The vex create a becon to alert the veil.");
        System.out.println("The becon reaches and the veil prepare there attack on the city.");
    }
    public static void ending54()
    {
        System.out.println("Title : Close Call.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The vex create a becon to alert the veil.");
        System.out.println("A guardian stops the vex and prevents the veil assault");
    }
    public static void ending55()
    {
        System.out.println("Title : A Growing Forest.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The vex try to create the infinte forest.");
        System.out.println("In days the seed becomes the largest tree with trillions of output and timelines");
        System.out.println("All used to study the light and a way to prevent it.");
    }
    public static void ending56()
    {
        System.out.println("Title : Another Close Call.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("The vex try to create the infinte forest.");
        System.out.println("A guardian stops the vex and prevents the vex forest");
    }
     public static void ending57()
    {
        System.out.println("Title : A Place Between Time.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Osiris talks to the guardian to explore the corridors of time.");
        System.out.println("He does so and finds a gun that could kill the darkness, changing the timeline");
    }
     public static void ending58()
    {
        System.out.println("Title : A Kingdom Between Time.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Osiris talks to the guardian to explore the corridors of time.");
        System.out.println("He does so and finds a ghost that has seen how to stop the darkness, changing the timeline");
    }
     public static void ending59()
     {
        System.out.println("Title : A Single Note.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Osiris talks to the guardian to explore the light houses.");
        System.out.println("He does some testing and finds that the towers sings a single note, the darkness is filling the system");
    }
     public static void ending60()
    {
        System.out.println("Title : A Double Note.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Osiris talks to the guardian to explore the light houses.");
        System.out.println("He does some testing and finds that the towers double a single note, the darkness is not in the system");
    }
     public static void ending61()
    {
        System.out.println("Title : A Scared Race.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Due to Osiris work the vex gather and fix the vault of glass.");
        System.out.println("But instead of fight the guardians run, causing the system to be ereased.");
    }
      public static void ending62()
    {
        System.out.println("Title : A Powerful Race.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Due to Osiris work the vex gather and fix the vault of glass.");
        System.out.println("The guardians fight and save the system.");
    }
      public static void ending63()
    {
        System.out.println("Title : A Dark Plan.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Due to Osiris work the sol vex gather and prepared a new vex.");
        System.out.println("Its was darkness infused and could destroy worlds.");
        System.out.println("His creation cuased my lives of guardians to be lost.");
    }
     public static void ending64()
    {
        System.out.println("Title : A Weak Group.");
        System.out.println("");
        System.out.println("In this time line. . .");
        System.out.println("Due to Osiris work the sol vex wait and prepared something.");
        System.out.println("There actions cause the vangaurd to put a stop to there plans.");
    }
}
