import java.io.*; 
import java.util.*; 
import java.util.Scanner;
import java.util.concurrent.TimeUnit;
/**
 * Set a path, explore the mysteries of the future and rewrite the past. Enter the tree of probabilities
 * (this is based off the destiny franchise, but can be enjoyed without any prior knowlegde)
 *
 * Focuses on integers, array list, scanners, and if, then statements
 *
 * @author John Jagger
 * @version 1.0.0
 * 
 * Hey Mr.Grossen this code is huge and very big, at the time of writing this I am finished
 * if there's a bug or one small thing not working sorry, I currently cant afford to spend more
 * time on this code wihout cutting time for other studies
 * I had fun making this code, even though the game itself isnt that funny ):
 * I tried to add everything I learned this year, which now looking back, is a lot
 * So, thank you for being an epic teacher and enjoy your break
 * stay safe and see you next year Mr. Grossen -- John Jagger
 * 
 */
public class TheForest
{
    public int seedsOfFuture = 0;
    static void main() throws InterruptedException
    {
        int seedsOfFuture = 0;
        
        Scanner future = new Scanner(System.in);
        
        ArrayList<String> timelines = new ArrayList<String>();
        
        intro();
        for (int i = 0; i<10; i++)
        {
        beginnings();
        
        String beginnings = future.nextLine();
        if(beginnings.equals("future"))
        {
            clearScreen();
            
            actionsAndResults a;
            a = new actionsAndResults();
            a.time1();
            
            oneOfMany c;
            c = new oneOfMany();
            
            String time1 = future.nextLine();
            if(time1.equals("earth"))
            {
                clearScreen();
                
                a.time2();
                
                String time2 = future.nextLine();
                if(time2.equals("light"))
                {
                    clearScreen();
                    
                    a.time3();
                    
                    String time3 = future.nextLine();
                    if (time3.equals("collapse"))
                    {
                        clearScreen();
                        
                        a.time4();
                        
                        String time4 = future.nextLine();
                        if (time4.equals("worthy"))
                        {
                            clearScreen();
                            
                            a.time5();
                            
                            String time5 = future.nextLine();
                            if (time5.equals("weak"))
                            {
                                c.ending1();
                                timelines.add("Broken Legends");
                                seedsOfFuture -= 50;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time5.equals("strong"))
                            {
                                c.ending2();
                                timelines.add("Unbroken Legends");
                                seedsOfFuture += 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time4.equals("unworthy"))
                        {
                            clearScreen();
                            
                            a.time6();
                            
                            String time6 = future.nextLine();
                            if (time6.equals("looked"))
                            {
                                c.ending3();
                                timelines.add("Weak Legends");
                                seedsOfFuture += 0;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time6.equals("resisted"))
                            {
                                c.ending4();
                                timelines.add("True Legends");
                                seedsOfFuture += 150;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                    else if (time3.equals("prosper"))
                    {
                        clearScreen();
                        
                        a.time7();
                        
                        String time7 = future.nextLine();
                        if (time7.equals("gold"))
                        {
                            clearScreen();
                            
                            a.time8();
                            
                            String time8 = future.nextLine();
                            if (time8.equals("unveiled"))
                            {
                                c.ending5();
                                timelines.add("An Ending Age");
                                seedsOfFuture -= 75;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time8.equals("unrevealed"))
                            {
                                c.ending6();
                                timelines.add("A Golden Age");
                                seedsOfFuture += 75;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time7.equals("rebuilding"))
                        {
                            clearScreen();
                            
                            a.time9();
                            
                            String time9 = future.nextLine();
                            if (time9.equals("yes"))
                            {
                                c.ending7();
                                timelines.add("A Waking Demon");
                                seedsOfFuture -= 50;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time9.equals("no"))
                            {
                                c.ending8();
                                timelines.add("A Rising Time");
                                seedsOfFuture += 80;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                }
                else if (time2.equals("darkness"))
                {
                    clearScreen();
                    
                    a.time10();
                    
                    String time10 = future.nextLine();
                    if (time10.equals("50"))
                    {
                        clearScreen();
                        
                        a.time11();
                        
                        String time11 = future.nextLine();
                        if (time11.equals("yes"))
                        {
                            clearScreen();
                            
                            a.time12();
                            
                            String time12 = future.nextLine();
                            if (time12.equals("hope"))
                            {
                                c.ending9();
                                timelines.add("The Candle in the Dark");
                                seedsOfFuture += 25;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time12.equals("fear"))
                            {
                                c.ending10();
                                timelines.add("A Slient Wimper");
                                seedsOfFuture -= 90;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time11.equals("no"))
                        {
                            clearScreen();
                            
                            a.time13();
                            
                            String time13 = future.nextLine();
                            if (time13.equals("fall"))
                            {
                                c.ending11();
                                timelines.add("Failure of a god");
                                seedsOfFuture -= 200;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time13.equals("stood"))
                            {
                                c.ending12();
                                timelines.add("In Times of Need");
                                seedsOfFuture += 50;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                    else if (time10.equals("90"))
                    {
                        clearScreen();
                        
                        a.time14();
                        
                        String time14 = future.nextLine();
                        if (time14.equals("fall"))
                        {
                            clearScreen();
                            
                            a.time15();
                            
                            String time15 = future.nextLine();
                            if (time15.equals("joined"))
                            {
                                c.ending13();
                                timelines.add("If You can't Beat them, Join them");
                                seedsOfFuture -= 500;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time15.equals("cried"))
                            {
                                c.ending14();
                                timelines.add("A Weak Species");
                                seedsOfFuture -= 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time14.equals("stood"))
                        {
                            clearScreen();
                            
                            a.time16();
                            
                            String time16 = future.nextLine();
                            if (time16.equals("hope"))
                            {
                                c.ending15();
                                timelines.add("Even Boys can Kill Giants");
                                seedsOfFuture += 1000;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time16.equals("weakness"))
                            {
                                c.ending16();
                                timelines.add("Salvation's Cry");
                                seedsOfFuture -= 175;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                }
            }
            else if (time1.equals("venus"))
            {
                clearScreen();
                
                a.time17();
                
                String time17 = future.nextLine();
                if(time17.equals("light"))
                {
                    clearScreen();
                    
                    a.time18();
                    
                    String time18 = future.nextLine();
                    if (time18.equals("stood"))
                    {
                        clearScreen();
                        
                        a.time19();
                        
                        String time19 = future.nextLine();
                        if (time19.equals("no"))
                        {
                            clearScreen();
                            
                            a.time20();
                            
                            String time20 = future.nextLine();
                            if (time20.equals("knowledgeable"))
                            {
                                c.ending17();
                                timelines.add("Smarter than Time Travelers");
                                seedsOfFuture += 200;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time20.equals("dumb"))
                            {
                                c.ending18();
                                timelines.add("Brain > Bronze");
                                seedsOfFuture -= 200;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time19.equals("yes"))
                        {
                            clearScreen();
                            
                            a.time21();
                            
                            String time21 = future.nextLine();
                            if (time21.equals("prevented"))
                            {
                                c.ending19();
                                timelines.add("Victors of the Vault");
                                seedsOfFuture += 600; 
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time21.equals("stood"))
                            {
                                c.ending20();
                                timelines.add("'Prefection'");
                                seedsOfFuture -= 300;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                    else if (time18.equals("broken"))
                    {
                        clearScreen();
                        
                        a.time22();
                        
                        String time22 = future.nextLine();
                        if (time22.equals("planning"))
                        {
                            clearScreen();
                            
                            a.time23();
                            
                            String time23 = future.nextLine();
                            if (time23.equals("yes"))
                            {
                                c.ending21();
                                timelines.add("A King's Mess");
                                seedsOfFuture += 15;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time23.equals("no"))
                            {
                                c.ending22();
                                timelines.add("A Grand Battle to Happen");
                                seedsOfFuture += 578;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time22.equals("rested"))
                        {
                            clearScreen();
                            
                            a.time24();
                            
                            String time24 = future.nextLine();
                            if (time24.equals("yes"))
                            {
                                c.ending23();
                                timelines.add("A New Home");
                                seedsOfFuture += 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time24.equals("no"))
                            {
                                c.ending24();
                                timelines.add("A Time of Peace");
                                seedsOfFuture += 150;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                }
                else if (time17.equals("darkness"))
                {
                    clearScreen();
                    
                    a.time25();
                    
                    String time25 = future.nextLine();
                    if (time25.equals("powered"))
                    {
                        clearScreen();
                        
                        a.time26();
                        
                        String time26 = future.nextLine();
                        if (time26.equals("closed"))
                        {
                            clearScreen();
                            
                            a.time27();
                            
                            String time27 = future.nextLine();
                            if (time27.equals("yes"))
                            {
                                c.ending25();
                                timelines.add("A Probelm Reborn");
                                seedsOfFuture -= 50;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time27.equals("no"))
                            {
                                c.ending26();
                                timelines.add("The Weekly Bad Guy");
                                seedsOfFuture += 60;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time26.equals("opened"))
                        {
                            clearScreen();
                            
                            a.time28();
                            
                            String time28 = future.nextLine();
                            if (time28.equals("powered"))
                            {
                                c.ending27();
                                timelines.add("Traveler? What's that?");
                                seedsOfFuture += 0;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time28.equals("left"))
                            {
                                c.ending28();
                                timelines.add("One Error to End them All.");
                                seedsOfFuture -= 1000;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                    else if (time25.equals("no"))
                    {
                        clearScreen();
                        
                        a.time29();
                        
                        String time29 = future.nextLine();
                        if (time29.equals("broken"))
                        {
                            clearScreen();
                            
                            a.time30();
                            
                            String time30 = future.nextLine();
                            if (time30.equals("powered"))
                            {
                                c.ending29();
                                timelines.add("The Day the Vex Attacked the City.");
                                seedsOfFuture -= 30;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time30.equals("broken"))
                            {
                                c.ending30();
                                timelines.add("Another Strike Down");
                                seedsOfFuture += 1;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time29.equals("shaped"))
                        {
                            clearScreen();
                            
                            a.time31();
                            
                            String time31 = future.nextLine();
                            if (time31.equals("hope"))
                            {
                                c.ending31();
                                timelines.add("A Destroyed Ships Keeps the Veil Away");
                                seedsOfFuture += 275;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time31.equals("hopeless"))
                            {
                                c.ending32();
                                timelines.add("It's all Gone");
                                seedsOfFuture -= 125;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                }
            }
        }
        else if(beginnings.equals("past"))
        {
            clearScreen();
            
            actionsAndResults b;
            b = new actionsAndResults();
            b.time32();
            
            oneOfMany d;
           d = new oneOfMany();
            
            String time32 = future.nextLine();
            if(time32.equals("earth"))
            {
                clearScreen();
                
   
                
                b.time33();
                
                String time33 = future.nextLine();
                if(time33.equals("light"))
                {
                    clearScreen();
                    
                    b.time34();
                    
                    String time34 = future.nextLine();
                    if (time34.equals("sorrow"))
                    {
                        clearScreen();
                        
                        b.time35();
                        
                        String time35 = future.nextLine();
                        if (time35.equals("heart"))
                        {
                            clearScreen();
                            
                            b.time36();
                            
                            String time36 = future.nextLine();
                            if (time36.equals("hope"))
                            {
                                d.ending33();
                                timelines.add("A Guardians Tale");
                                seedsOfFuture += 50;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time36.equals("hopeless"))
                            {
                                d.ending34();
                                timelines.add("Before the Light");
                                seedsOfFuture += 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time35.equals("sword"))
                        {
                            clearScreen();
                            
                            b.time37();
                            
                            String time37 = future.nextLine();
                            if (time37.equals("smart"))
                            {
                                d.ending35();
                                timelines.add("Spawn Killer");
                                seedsOfFuture += 70;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time37.equals("punch"))
                            {
                                d.ending36();
                                timelines.add("A Great Failure");
                                seedsOfFuture -= 90;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                    else if (time34.equals("happiness"))
                    {
                        clearScreen();
                        
                        b.time38();
                        
                        String time38 = future.nextLine();
                        if (time38.equals("yes"))
                        {
                            clearScreen();
                            
                            b.time39();
                            
                            String time39 = future.nextLine();
                            if (time39.equals("moon"))
                            {
                                d.ending37();
                                timelines.add("A Golden Age Nightmare");
                                seedsOfFuture += 55;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time39.equals("titan"))
                            {
                                d.ending38();
                                timelines.add("The End");
                                seedsOfFuture -= 1000;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time38.equals("no"))
                        {
                            clearScreen();
                            
                            b.time40();
                            
                            String time40 = future.nextLine();
                            if (time40.equals("formed"))
                            {
                                d.ending39();
                                timelines.add("A Tyrant");
                                seedsOfFuture += 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time40.equals("awaken"))
                            {
                                d.ending40();
                                timelines.add("A Traveler");
                                seedsOfFuture += 450;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                }
                else if (time33.equals("blinded"))
                {
                    clearScreen();
                    
                    b.time41();
                    
                    String time41 = future.nextLine();
                    if (time41.equals("visit"))
                    {
                        clearScreen();
                    
                        b.time42();
                        
                        String time42 = future.nextLine();
                        if (time42.equals("hope"))
                        {
                            clearScreen();
                    
                            b.time43();
                            
                            String time43 = future.nextLine();
                            if (time43.equals("welcome"))
                            {
                                d.ending41();
                                timelines.add("A Trip of a Life Time");
                                seedsOfFuture += 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time43.equals("fear"))
                            {
                                d.ending42();
                                timelines.add("A Missed Opertunity");
                                seedsOfFuture -= 1000;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time42.equals("dread"))
                        {
                            clearScreen();
                            
                            b.time44();
                            
                            String time44 = future.nextLine();
                            if (time44.equals("scare"))
                            {
                                d.ending43();
                                timelines.add("A Trip of Death");
                                seedsOfFuture -= 300;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time44.equals("anger"))
                            {
                                d.ending44();
                                timelines.add("A Trip of Rage");
                                seedsOfFuture -= 450;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                    else if (time41.equals("ignore"))
                    {
                        clearScreen();
                    
                        b.time45();
                        
                        String time45 = future.nextLine();
                        if (time45.equals("passes"))
                        {
                            clearScreen();
                            
                            b.time46();
                            
                            String time46 = future.nextLine();
                            if (time46.equals("stays"))
                            {
                                d.ending45();
                                timelines.add("The Wrong Type of Attention");
                                seedsOfFuture -= 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time46.equals("leaves"))
                            {
                                d.ending46();
                                timelines.add("Lucky");
                                seedsOfFuture += 777;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time45.equals("ignores"))
                        {
                            clearScreen();
                            
                            b.time47();
                            
                            String time47 = future.nextLine();
                            if (time47.equals("light"))
                            {
                                d.ending47();
                                timelines.add("Second Chance");
                                seedsOfFuture += 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time47.equals("blinded"))
                            {
                                d.ending48();
                                timelines.add("Normality");
                                seedsOfFuture += 0;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                }
            }
            else if (time32.equals("mercury"))
            {
                clearScreen();
                
                b.time48();
                
                String time48 = future.nextLine();
                if(time48.equals("hope"))
                {
                    clearScreen();
                    
                    b.time49();
                    
                    String time49 = future.nextLine();
                    if (time49.equals("opened"))
                    {
                        clearScreen();
                    
                        b.time50();
                        
                        String time50 = future.nextLine();
                        if (time50.equals("planted"))
                        {
                            clearScreen();
                    
                            b.time51();
                            
                            String time51 = future.nextLine();
                            if (time51.equals("free"))
                            {
                                d.ending49();
                                timelines.add("Savior");
                                seedsOfFuture += 1400; 
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time51.equals("dont"))
                            {
                                d.ending50();
                                timelines.add("A Normal Day");
                                seedsOfFuture += 0;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time50.equals("no"))
                        {
                            clearScreen();
                    
                            b.time52();
                            
                            String time52 = future.nextLine();
                            if (time52.equals("either"))
                            {
                                d.ending51();
                                timelines.add("A Fallen Raiding Party");
                                seedsOfFuture -= 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time52.equals("gas"))
                            {
                                d.ending52();
                                timelines.add("A War with the Cabal");
                                seedsOfFuture += 333;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                    else if (time49.equals("closed"))
                    {
                        clearScreen();
                    
                        b.time53();
                        
                        String time53 = future.nextLine();
                        if (time53.equals("becon"))
                        {
                            clearScreen();
                    
                            b.time54();
                            
                            String time54 = future.nextLine();
                            if (time54.equals("yes"))
                            {
                                d.ending53();
                                timelines.add("A Day with Death");
                                seedsOfFuture -= 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time54.equals("no"))
                            {
                                d.ending54();
                                timelines.add("Close Call");
                                seedsOfFuture += 420;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time53.equals("growing"))
                        {
                            clearScreen();
                    
                            b.time55();
                            
                            String time55 = future.nextLine();
                            if (time55.equals("yes"))
                            {
                                d.ending55();
                                timelines.add("A Growing Forest");
                                seedsOfFuture += 567;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time55.equals("no"))
                            {
                                d.ending56();
                                timelines.add("Another Close Call");
                                seedsOfFuture += 690;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                }
                else if (time48.equals("dread"))
                {
                    clearScreen();
                    
                    b.time56();
                    
                    String time56 = future.nextLine();
                    if (time56.equals("present"))
                    {
                        clearScreen();
                    
                        b.time57();
                        
                        String time57 = future.nextLine();
                        if (time57.equals("spinning"))
                        {
                            clearScreen();
                    
                            b.time58();
                            
                            String time58 = future.nextLine();
                            if (time58.equals("power"))
                            {
                                d.ending57();
                                timelines.add("A Place Between Time");
                                seedsOfFuture += 150;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time58.equals("fortune"))
                            {
                                d.ending58();
                                timelines.add("A Kingdom Between Time");
                                seedsOfFuture += 300;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time57.equals("active"))
                        {
                            clearScreen();
                    
                            b.time59();
                            
                            String time59 = future.nextLine();
                            if (time59.equals("single note"))
                            {
                                d.ending59();
                                timelines.add("A Single Note");
                                seedsOfFuture -= 777;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time59.equals("double note"))
                            {
                                d.ending60();
                                timelines.add("A Double Note");
                                seedsOfFuture += 777;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                    else if (time56.equals("scearhing"))
                    {
                        clearScreen();
                    
                        b.time60();
                        
                        String time60 = future.nextLine();
                        if (time60.equals("gather"))
                        {
                            clearScreen();
                    
                            b.time61();
                            
                            String time61 = future.nextLine();
                            if (time61.equals("run"))
                            {
                                d.ending61();
                                timelines.add("A Scared Race");
                                seedsOfFuture -= 10;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time61.equals("conquier"))
                            {
                                d.ending62();
                                timelines.add("A Powerful Race");
                                seedsOfFuture += 500;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                        else if (time60.equals("scatter"))
                        {
                            clearScreen();
                    
                            b.time62();
                            
                            String time62 = future.nextLine();
                            if (time62.equals("yes"))
                            {
                                d.ending63();
                                timelines.add("A Dark Plan");
                                seedsOfFuture -= 100;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                            else if (time62.equals("no"))
                            {
                                d.ending64();
                                timelines.add("A Weak Group");
                                seedsOfFuture -= 200;
                                delayDots(7);
                                System.out.println("Here's your titles: " + timelines);
                                delayDots(3);
                                clearScreen();
                            }
                        }
                    }
                }
            }
        }
    }
    if (seedsOfFuture >= 1000)
    {
        System.out.println("Here's all of your titles: " + timelines);
        System.out.println("");
        System.out.println("Your rank is : Legendary!! Points: " + seedsOfFuture);
        System.out.println("");
        System.out.println("You've successfully traveled the forest!!");
        System.out.println("Yet a hum of a single note can be heard. . .");
        delayDots(3);
        System.out.println("The forest will close now, restart to journey once again.");
        delayDots(3);
        clearScreen();
        seedsOfFuture = 0;
    }
    else if(seedsOfFuture <= -1)
    {
        System.out.println("Here's all of your titles: " + timelines);
        System.out.println("");
        System.out.println("Your rank is : Darkend!! Points: " + seedsOfFuture);
        System.out.println("");
        System.out.println("A hum gets louder and louder.");
        delayDots(3);
        clearScreen();
        fight();
    }
    else
    {
        System.out.println("Here's all of your titles: " + timelines);
        System.out.println("");
        System.out.println("Your rank is : Null!! Points: " + seedsOfFuture);
        System.out.println("");
        System.out.println("Wow you suck at this. . .");
    }
    
    }
    
     public static void clearScreen()
    {
        System.out.print('\u000C');
    }
    
    public static void beginnings()
    {
        System.out.println("What era would you like to see?");
        System.out.println("- future"); 
        System.out.println("- past"); 
    }
    
    public static void intro() throws InterruptedException
    {
        System.out.println("T r e e    o f    P r o b a b i l i t i e s");
        System.out.println("          _-_");
        System.out.println("       /~~   ~~\\");
        System.out.println("     /~~       ~~\\");
        System.out.println("    {             }");
        System.out.println("    \\  _-     -_  /");
        System.out.println("      ~  \\\\ //  ~");
        System.out.println("    _- -  | | _- _");
        System.out.println("      _ - | |   -_");
        System.out.println("         // \\\\");
        System.out.println("Press anything to see more");
        
        Scanner time = new Scanner(System.in);
        String tony = time.nextLine();
        clearScreen();
        
        System.out.println("Welcome to the tree of probabilities, a destiny based game.");
        System.out.println("");
        System.out.println("Detail: This game is a question type game, you are given ");
        System.out.println("a quetion and your answer will lead to a different ");
        System.out.println("question until you get to last question and you are given");
        System.out.println("a title and points. There are 64 possible titles to get.");
        System.out.println("");
        System.out.println("Rules: the goal is to get the highest score. When starting you are given");
        System.out.println("5 attempts at getting titles, after that 5, you are given your results");
        System.out.println("depending on your point score different things will happen.");
        System.out.println("");
        System.out.println("Note: type the response as seen in screen or your input will fail.");
        System.out.println("");
        delayDots(3);
        System.out.println("");
        System.out.println("One more thing there's a wasted timeline?!");
        System.out.println("This happens when a incorrect input is made");
        System.out.println("It forces you back to the front and uses one of the 5");
        System.out.println("timelines you can uses to get points");
        System.out.println("");
        System.out.println("Press anything to start");
        
        Scanner time70 = new Scanner(System.in);
        String ron = time70.nextLine();
        clearScreen();
        
        
        
        delayDots(3);
        clearScreen();
        System.out.println("Game Start!!");
        clearScreen();
        delayDots(3);
        clearScreen();
        
       
    }
    public static void fight() throws InterruptedException
    {
        Scanner fight = new Scanner(System.in);
        String battle1 = fight.nextLine();
         if (battle1.equals("fight"))
         {
             death1();
             System.out.println("No really game over. . .");
             delayDots(5);
             clearScreen();
            }
         else if (battle1.equals("run"))
         {
             death2();
             System.out.println("No really game over. . .");
             delayDots(5);
             clearScreen();
            }  
         else if (battle1.equals("hide"))
         {
             hide();
             String battle2 = fight.nextLine();
             if (battle2.equals("fight"))
             {
                 clearScreen();
                 victory();
              }
              else if (battle1.equals("run"))
              {
                  death3();
                  System.out.println("No really game over. . .");
                  delayDots(5);
                  clearScreen();
                }
                else
                {
                    System.out.println("Your actions failed and fell to the veil. . . GAME OVER");
                  delayDots(5);
                  clearScreen();
                }
            }
            else
            {
                System.out.println("Your actions failed and fell to the veil. . . GAME OVER");
                  delayDots(5);
                  clearScreen();
            }
    }
    public static void death1()
    {
        System.out.println("You tried to fight and died, GAME OVER!!");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
    }
    public static void death2()
    {
        System.out.println("You tried to run and got eaten by the veil fighter, GAME OVER!!");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
    }
    public static void hide()
    {
        System.out.println("You hide behind a vex statue . . . What now?");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
        System.out.println( "============================"); 
        System.out.println( "=== fight     or    run  ===");
        System.out.println( "============================");
    }
    public static void death3()
    {
        System.out.println("You tried to run and got eaten by the veil fighter, GAME OVER!!");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
    }
    public static void victory()
    {
        System.out.println("You killed the veil fighter");
        System.out.println("");
        System.out.println("Turns out he attack because of all the bad timelines you made");
        System.out.println("");
        System.out.println("Well, seems you need to run the forest again for a better score. . .");
        System.out.println("");
        System.out.println("Good bye and Thanks!!");
    }
    public static void theVeil()
    {
        System.out.println("Out of nowhere a veil fighter steps out of the forest!!");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
        System.out.println( "============================"); 
        System.out.println( "=== fight or run or hide ===");
        System.out.println( "============================");
    }
    
    
    public static void delayDots(int dotAmount) throws InterruptedException
    {
        for(int i=0; i<dotAmount; i++)
        {
            TimeUnit.SECONDS.sleep(1);
            System.out.print("△ ");
        }
        System.out.println();
    }

    public static void delayDots() throws InterruptedException
    {
        delayDots(0);
    }
}
