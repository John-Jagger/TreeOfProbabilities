import java.util.Scanner;
/**
 * A boss battle for a "darkend" ending of the game
 *
 * @author John Jagger
 * @version 1.0.0
 */
public class theVeil
{
    public static void main()
    {
         Scanner fight = new Scanner(System.in);
         String battle1 = fight.nextLine();
         if (battle1.equals("fight"))
         {
             death1();
             System.out.println("No really game over. . .");
            }
         else if (battle1.equals("run"))
         {
             death2();
             System.out.println("No really game over. . .");
            }  
         else if (battle1.equals("hide"))
         {
             hide();
             String battle2 = fight.nextLine();
             if (battle2.equals("fight"))
             {
                 victory();
              }
              else if (battle1.equals("run"))
              {
                  death3();
                  System.out.println("No really game over. . .");
                }
            }
    }
    public static void death1()
    {
        System.out.println("You tried to fight and died, GAME OVER!!");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
    }
    public static void death2()
    {
        System.out.println("You tried to run and got eaten by the veil fighter, GAME OVER!!");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
    }
    public static void hide()
    {
        System.out.println("You hide behind a vex statue . . . What now?");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
        System.out.println( "============================"); 
        System.out.println( "=== fight     or    run  ===");
        System.out.println( "============================");
    }
    public static void death3()
    {
        System.out.println("You tried to run and got eaten by the veil fighter, GAME OVER!!");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
    }
    public static void victory()
    {
        System.out.println("You killed the veil fighter");
        System.out.println("");
        System.out.println("Turns out he attack because of all the bad timelines you made");
        System.out.println("");
        System.out.println("Well, seems you need to run the forest again for a better score. . .");
        System.out.println("");
        System.out.println("Good bye and Thanks!!");
    }
    public static void theVeil()
    {
        System.out.println("Out of nowhere a veil fighter steps out of the forest!!");
        System.out.println("");
        System.out.println("        ___");
        System.out.println("      _/ ..\\");
        System.out.println("     ( \\  0/__");
        System.out.println("      \\     \\__)");
        System.out.println("       /     \\");
        System.out.println("      /      _\\");
        System.out.println("      ---------");
        System.out.println( "============================"); 
        System.out.println( "=== fight or run or hide ===");
        System.out.println( "============================");
    }
}
